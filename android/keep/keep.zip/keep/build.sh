#!/usr/bin/env bash

dart2native bin/convert.dart -o convert
